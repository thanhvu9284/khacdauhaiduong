from django.apps import AppConfig


class BottomConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bottom'
