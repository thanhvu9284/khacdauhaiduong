from django.apps import AppConfig


class DichvuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dichvu'
